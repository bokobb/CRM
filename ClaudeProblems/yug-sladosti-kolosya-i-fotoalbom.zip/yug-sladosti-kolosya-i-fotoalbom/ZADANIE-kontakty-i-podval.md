# Задание: контакты и подвал под настоящие данные

Задание для Claude Code в проекте CRM «Юг Сладости». Сначала прочитай `CLAUDE.md`; его правила важнее этого текста.
Правки касаются только промо-страницы: секция «Контакты» и подвал. Образец — обновлённый макет промо-страницы.

## Что сейчас не так

После того как в контакты и подвал вписали настоящие данные (два телефона, Instagram, длинный адрес, почта,
ссылки на PDF-каталог и вход для сотрудников), обе части разъехались:

- **Подвал.** Всё, кроме разделов, сложено в одну правую колонку: семь пунктов с одинаковыми большими
  отступами, без заголовков. Колонка вытянулась вниз, слева под логотипом пусто.
- **Контакты.** Список контактов стоит под текстом в левой колонке, и она стала заметно выше формы справа:
  под формой остаётся пустое жёлтое поле. Сам блок уже, чем остальные секции страницы, — его край не совпадает
  с краем каталога и подвала.

## Как должно быть

- **Контакты.** Текст с кнопкой и форма стоят рядом и выровнены по центру друг друга. Контакты идут под ними
  одной полосой во всю ширину секции: телефоны, Instagram, почта, адрес, между ними тонкие линии. На планшете —
  два на два, на телефоне — списком; на телефоне контакты стоят перед формой. Ширина секции — как у остальных
  (`.wrap`); если у контактов есть своё ограничение ширины, убери его.
- **Подвал.** Четыре колонки с небольшими заголовками: логотип с подписью, кнопкой «Заказать онлайн» и ссылкой
  на каталог; «Разделы»; «Связаться» (телефоны, Instagram); «Адрес производства». На планшете логотип — строкой
  сверху, под ним три колонки; на телефоне «Разделы» и «Связаться» рядом, адрес под ними; на самых узких — одной колонкой.
  Внизу слева «© 2026 Юг Сладости», справа «Вход для сотрудников».
- **Адрес** разбит на две строки: основной адрес и в скобках второй, мельче. Короткие слова склеены неразрывным
  пробелом с тем, что после них (`г.&nbsp;Шымкент`, `ж/м&nbsp;Исфиджаб`, `ул.&nbsp;…`, `Елебекова,&nbsp;128`), чтобы строка
  не заканчивалась на «ул.».

## Разметка

Данные и ссылки — те, что сейчас на сайте; если в шаблоне они берутся из настроек или базы, подставляй оттуда же.
Форма «Перезвоните мне» остаётся как есть, меняется только её место: список контактов переезжает из колонки с текстом
вниз, после формы.

```html
<section class="section contact" id="contacts">
  <span class="wheat" aria-hidden="true"></span>
  <div class="wrap contact-in">
    <div class="contact-copy">
      <p class="eyebrow">Контакты</p>
      <h2>Закажите онлайн или оставьте номер</h2>
      <p class="lead">Быстрее всего — оформить заказ онлайн. Хотите сначала обсудить условия — оставьте номер, мы перезвоним.</p>
      <a class="btn btn-primary" href="/shop" target="_blank" rel="noopener">Заказать онлайн
        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"></path></svg>
      </a>
    </div>
    <form class="form" id="lead" novalidate> … форма без изменений … </form>
    <ul class="contact-list">
      <li>
        <span class="c-ic" aria-hidden="true"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2Z"></path></svg></span>
        <span class="c-t"><span class="c-l">Телефон / сотрудничество</span><a class="c-v" href="tel:+77750050230">+7 775 005 02 30</a><a class="c-v" href="tel:+77787003902">+7 778 700 39 02</a></span>
      </li>
      <li>
        <span class="c-ic" aria-hidden="true"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="3.5" width="17" height="17" rx="5"></rect><circle cx="12" cy="12" r="4"></circle><circle cx="17.3" cy="6.7" r=".6" fill="currentColor"></circle></svg></span>
        <span class="c-t"><span class="c-l">Instagram</span><a class="c-v" href="https://www.instagram.com/yug_sladosti" target="_blank" rel="noopener">@yug_sladosti</a></span>
      </li>
      <li>
        <span class="c-ic" aria-hidden="true"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2.5"></rect><path d="m4 7 8 6 8-6"></path></svg></span>
        <span class="c-t"><span class="c-l">Почта</span><span class="c-v">yug-sladosti.kz</span></span>
      </li>
      <li>
        <span class="c-ic" aria-hidden="true"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21s-7-6.2-7-11a7 7 0 0 1 14 0c0 4.8-7 11-7 11Z"></path><circle cx="12" cy="10" r="2.5"></circle></svg></span>
        <span class="c-t"><span class="c-l">Адрес производства</span><span class="c-v">г.&nbsp;Шымкент, ж/м&nbsp;Исфиджаб, ул.&nbsp;Жусипбека Елебекова,&nbsp;128</span><span class="c-sub">(ул.&nbsp;Елебекова,&nbsp;135а, Енбекшинский&nbsp;район)</span></span>
      </li>
    </ul>
  </div>
</section>
```

```html
<footer class="foot">
  <span class="wheat" aria-hidden="true"></span>
  <div class="wrap foot-in">
    <div class="foot-brand">
      <img src="img/logo.svg" alt="Юг Сладости. Кондитерская" width="384" height="223" loading="lazy">
      <p>Кондитерская с собственным производством. Выпечка к чаю оптом.</p>
      <div class="foot-cta">
        <a class="btn btn-yolk btn-sm" href="/shop" target="_blank" rel="noopener">Заказать онлайн <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"></path></svg></a>
        <a class="foot-pdf" href="/promo/katalog.pdf" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 4v11m0 0-4.5-4.5M12 15l4.5-4.5M5 20h14"></path></svg>Скачать каталог <small>PDF, 8,6 МБ</small></a>
      </div>
    </div>
    <nav class="foot-col" aria-label="Разделы в подвале">
      <p class="foot-h">Разделы</p>
      <a href="#catalog">Каталог</a>
      <a href="#how">Как заказать</a>
      <a href="#about">О кондитерской</a>
      <a href="#contacts">Контакты</a>
    </nav>
    <div class="foot-col">
      <p class="foot-h">Связаться</p>
      <a class="foot-link" href="tel:+77750050230">+7 775 005 02 30</a>
      <a class="foot-link" href="tel:+77787003902">+7 778 700 39 02</a>
      <a class="foot-link" href="https://www.instagram.com/yug_sladosti" target="_blank" rel="noopener">Instagram <small>@yug_sladosti</small></a>
    </div>
    <div class="foot-col foot-where">
      <p class="foot-h">Адрес производства</p>
      <p class="foot-addr">г.&nbsp;Шымкент, ж/м&nbsp;Исфиджаб, ул.&nbsp;Жусипбека Елебекова,&nbsp;128<small>(ул.&nbsp;Елебекова,&nbsp;135а, Енбекшинский&nbsp;район)</small></p>
    </div>
  </div>
  <div class="wrap"><div class="foot-end"><span>© 2026 Юг Сладости</span><a href="/login">Вход для сотрудников</a></div></div>
</footer>
```

## Стили

Замени правила `.contact-in`, `.contact-copy`, `.contact-list`, `.c-*` и все правила подвала (`.foot-in`, `.foot-brand`,
`.foot nav`, `.foot-info`, `.foot-end`) на блок ниже. Правила формы (`.form`, `.field`) и фон секций не меняй.
Блок ставь после общих стилей, а его `@media` — после остальных `@media` страницы.

```css
/* ---- Контакты: текст и форма рядом, по центру друг друга; контакты — одной полосой во всю ширину под ними ---- */
.contact-in{position:relative;display:grid;grid-template-columns:minmax(0,1.05fr) minmax(0,.95fr);align-items:center;gap:clamp(32px,4vw,52px) clamp(28px,5vw,72px)}
.contact-copy{display:grid;gap:20px;justify-items:start;min-width:0}
.contact-list{grid-column:1/-1;display:grid;grid-template-columns:minmax(0,1fr) minmax(0,.8fr) minmax(0,.8fr) minmax(0,1.55fr);margin:0;padding:26px 0 0;border-top:1px solid var(--line-strong);list-style:none}
.contact-list li{display:flex;align-items:flex-start;gap:12px;min-width:0;padding:2px clamp(14px,1.8vw,24px);border-left:1px solid var(--line-strong)}
.contact-list li:first-child{padding-left:0;border-left:0}
.c-ic{display:grid;place-items:center;flex:none;width:40px;height:40px;border-radius:50%;background:var(--ink);color:#fff}
.c-t{display:grid;gap:2px;min-width:0}
.c-l{display:block;font-size:13.5px;line-height:1.3}
.c-v{display:block;width:fit-content;font-weight:600;line-height:1.35;overflow-wrap:anywhere;text-decoration:none}
a.c-v:hover{text-decoration:underline}
.c-sub{display:block;font-size:14px;line-height:1.35;color:rgba(42,23,18,.78)}

/* ---- Подвал: четыре колонки, у каждой свой небольшой заголовок ---- */
.foot-in{position:relative;display:grid;grid-template-columns:minmax(0,1.25fr) minmax(0,.6fr) minmax(0,.85fr) minmax(0,1.05fr);gap:34px clamp(24px,3.5vw,52px);padding-block:clamp(44px,5vw,64px) 34px}
.foot-brand{display:grid;gap:16px;justify-items:start;align-content:start}
.foot-brand img{height:84px;width:auto}
.foot-brand p{max-width:24em;font-size:15px;color:rgba(255,255,255,.88)}
.foot-cta{display:flex;flex-wrap:wrap;align-items:center;gap:10px 22px;margin-top:2px}
.foot-pdf{display:inline-flex;align-items:center;gap:8px;min-height:44px;font-size:15px;font-weight:600;color:var(--yolk);text-decoration:none}
.foot-pdf svg{flex:none}
.foot-pdf small{font-size:13.5px;font-weight:400;color:rgba(255,255,255,.75)}
.foot-pdf:hover{text-decoration:underline}
.foot-col{display:grid;align-content:start;justify-items:start;min-width:0}
.foot-h{margin-bottom:8px;font:italic 600 17px/1.25 var(--font-display);color:rgba(255,255,255,.72)}
.foot-col a{display:inline-flex;flex-wrap:wrap;align-items:center;column-gap:6px;min-height:40px;font-size:16px;text-decoration:none}
.foot-col a:hover{text-decoration:underline}
.foot-link{font-weight:600;color:var(--yolk)}
.foot-link small{font-size:15px;font-weight:400;color:rgba(255,255,255,.8)}
.foot-addr{font-size:15px;line-height:1.5;color:rgba(255,255,255,.9)}
.foot-addr small{display:block;margin-top:4px;font-size:14px;color:rgba(255,255,255,.72)}
.foot-end{position:relative;display:flex;flex-wrap:wrap;justify-content:space-between;gap:6px 24px;padding-block:18px 26px;border-top:1px solid rgba(255,255,255,.24);font-size:13.5px;color:rgba(255,255,255,.8)}
.foot-end a{color:inherit}

@media (max-width:1080px){
  .contact-list{grid-template-columns:repeat(2,minmax(0,1fr));row-gap:22px}
  .contact-list li:nth-child(odd){padding-left:0;border-left:0}
  .foot-in{grid-template-columns:repeat(3,minmax(0,1fr))}
  .foot-brand{grid-column:1/-1}
}
@media (max-width:900px){
  .contact-in{grid-template-columns:minmax(0,1fr);align-items:start}
  .contact-list{order:1}                     /* на телефоне номера идут раньше формы */
  .form{order:2}
}
@media (max-width:560px){
  .contact-list{grid-template-columns:minmax(0,1fr);padding-top:0;border-top:0}
  .contact-list li,.contact-list li:nth-child(odd){padding:14px 0;border-left:0;border-top:1px solid var(--line-strong)}
  .contact-list li:last-child{border-bottom:1px solid var(--line-strong)}
  .foot-in{grid-template-columns:minmax(0,1fr) minmax(0,1fr);column-gap:20px}
  .foot-brand,.foot-where{grid-column:1/-1}
}
@media (max-width:380px){
  .foot-in{grid-template-columns:minmax(0,1fr)}
  .field select{padding-inline:12px 8px}    /* «Магазин или минимаркет» помещается рядом со стрелкой */
}
```

## Почта

В строке «Почта» сейчас написано `yug-sladosti.kz` — это адрес сайта, а не почты, и ссылки у него нет. Спроси
у владельца адрес почты (вида `…@yug-sladosti.kz`) и сделай его ссылкой `mailto:`. Если почты пока нет — убери строку,
а колонки полосы контактов на компьютере поменяй на `minmax(0,1fr) minmax(0,.9fr) minmax(0,1.6fr)`.

## Как проверить

- [ ] На ширине 1440 и 1920: в контактах текст и форма одной высоты по центру друг друга, под ними полоса из четырёх
      контактов; края секции совпадают с краями каталога и подвала.
- [ ] Подвал на 1440: четыре колонки с заголовками, ничего не стоит столбиком на всю высоту.
- [ ] На 768: контакты два на два, подвал — логотип сверху и три колонки.
- [ ] На 390 и 320: контакты списком перед формой, «Магазин или минимаркет» в списке целиком; подвал без
      горизонтальной прокрутки, нижнюю строку не закрывает панель «Заказать онлайн».
- [ ] Телефоны звонят по нажатию, Instagram и PDF открываются, «Вход для сотрудников» ведёт на страницу входа.
- [ ] Адрес нигде не переносится так, что строка заканчивается на «г.», «ж/м» или «ул.».
