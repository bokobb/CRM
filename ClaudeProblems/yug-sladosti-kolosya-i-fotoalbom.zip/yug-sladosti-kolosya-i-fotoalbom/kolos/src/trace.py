# Step 1 of 2. Vectorise the catalogue's three-ear line art (catalog-ears.png, the bitmap from page 3 of the PDF)
# in two tones, the way the bitmap reads:
#   "light" — every stroke at its visible width (drawn pale);  "dark" — the cores of the bold strokes (drawn full strength).
#   python3 trace.py          → trace.json: paths in the bitmap's own pixel units (1131 x 882, y down)
# Needs: numpy, opencv-python, pillow, potracer (pip install potracer).  Step 2 is make_art.py.
import json, pathlib, time
import numpy as np, cv2, potrace
from PIL import Image
HERE = pathlib.Path(__file__).parent
K, TOL = 4, 0.4                 # work at 4x the bitmap's resolution; curve-fitting tolerance
DARK_FROM, FAINT, STRONG = 0.5, 0.13, 0.78
E1, E2 = max(1, round(0.5 * K)), max(2, round(1.25 * K))
# the bitmap is brown ink on the catalogue's yellow: turn it into ink coverage 0..1
rgb = np.asarray(Image.open(HERE / 'catalog-ears.png').convert('RGB')).astype(float)
paper, ink = np.array([255., 198., 70.]), np.array([113., 80., 25.])
alpha = np.clip(((paper - rgb) @ (paper - ink)) / ((paper - ink) @ (paper - ink)), 0, 1).astype(np.float32)
H, W = alpha.shape
big = cv2.resize(alpha, (W * K, H * K), interpolation=cv2.INTER_CUBIC)
big = np.clip(cv2.GaussianBlur(big, (0, 0), 0.22 * K), 0, 1)       # takes the pixel stair-steps out of the edges
r = max(1, int(round(0.8 * K)))
peak = cv2.dilate(big, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * r + 1, 2 * r + 1)))   # crest of the stroke a pixel belongs to
light = (big > np.maximum(0.5 * peak, 0.07)) & (peak > FAINT)       # half height: the width the eye sees
# The bitmap is soft, so a hairline thinner than a pixel shows up faint rather than thin. The crisp line carrying
# the same ink as a soft line with crest p is its cut at p*exp(-0.785 p^2) (exact for a Gaussian profile).
dark = (big > peak * np.exp(-0.785 * peak * peak)) & (peak > DARK_FROM)
# keep a dark core only where the stroke really gets bold somewhere: a hairline hovering around the limit
# would otherwise come out as a row of dark dashes
n, lab = cv2.connectedComponents(dark.astype(np.uint8), connectivity=8)
strong = np.zeros(n, bool); strong[np.unique(lab[big > STRONG])] = True; strong[0] = False
dark = strong[lab]
# the pale layer is only needed where there is no bold core over it: hairlines and the thin ends of bold strokes
# (it stays under cores thinner than a pixel, so a stroke never breaks where it changes tone)
k1 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * E1 + 1, 2 * E1 + 1)); k2 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * E2 + 1, 2 * E2 + 1))
covered = cv2.dilate(cv2.erode(dark.astype(np.uint8), k1), k2).astype(bool)
light = light & ~covered

def trace(mask):
    plist = potrace.Bitmap(~mask).trace(turdsize=int(1.2 * K * K), turnpolicy=potrace.POTRACE_TURNPOLICY_MINORITY, alphamax=1.0, opticurve=True, opttolerance=TOL)   # this tracer takes False as ink
    paths, n = [], 0
    for curve in plist:
        s = curve.start_point
        px, py, segs = s.x, s.y, []
        for g in curve.segments:
            if g.is_corner:      # two straight pieces through the corner point
                for (ex, ey) in ((g.c.x, g.c.y), (g.end_point.x, g.end_point.y)):
                    segs.append([round(ex / K, 2), round(ey / K, 2)]); px, py = ex, ey
            else:
                segs.append([round(v / K, 2) for v in (g.c1.x, g.c1.y, g.c2.x, g.c2.y, g.end_point.x, g.end_point.y)]); px, py = g.end_point.x, g.end_point.y
        n += len(segs)
        paths.append({'m': [round(s.x / K, 2), round(s.y / K, 2)], 's': segs})
    return paths, n
t0 = time.time()
L, nl = trace(light); D, nd = trace(dark)
json.dump({'w': W, 'h': H, 'light': L, 'dark': D}, open(HERE / 'trace.json', 'w'))
print(f'trace.json: light {len(L)} paths / {nl} segments, dark {len(D)} paths / {nd} segments, {time.time()-t0:.0f}s')
