# Step 2 of 2. Traced line art → compact data for kolos.js.
#   python3 make_art.py        reads trace.json (bitmap pixel units, as on catalogue page 3: ears pointing up-left)
#                              writes art.json: mirrored (stems bottom-left, ears pointing up-right, as on page 6)
# Then build.py puts art.json into kolos.src.js and writes ../kolos.js.
import json, pathlib
import numpy as np, cv2
HERE = pathlib.Path(__file__).parent
d = json.loads((HERE / 'trace.json').read_text())
W, H, Q = d['w'], d['h'], 10                       # Q: coordinates are stored in tenths of a bitmap pixel
PIVOT = (108, 850)                                 # where the stems meet (mirrored coordinates)

def mirror(seg):
    return [W - v if i % 2 == 0 else v for i, v in enumerate(seg)]

allpts = []
def encode(paths):
    out = []
    for p in paths:
        x, y = mirror(p['m']); ix, iy = round(x * Q), round(y * Q); allpts.append((x, y))
        s = ['M%d,%d' % (ix, iy)]
        for g in p['s']:
            g = mirror(g)
            pts = [(round(g[i] * Q), round(g[i + 1] * Q)) for i in range(0, len(g), 2)]
            for i in range(0, len(g), 2): allpts.append((g[i], g[i + 1]))
            rel = []
            for (px, py) in pts: rel += [px - ix, py - iy]
            ix, iy = pts[-1]
            s.append(('l' if len(g) == 2 else 'c') + ','.join(map(str, rel)))
        out.append(''.join(s))
    return ''.join(out).replace(',-', '-')

light, dark = encode(d['light']), encode(d['dark'])
P = np.array(allpts, np.float32)
hull = cv2.convexHull(P).reshape(-1, 2)
hull = cv2.approxPolyDP(hull.reshape(-1, 1, 2), 1.5, True).reshape(-1, 2)      # a couple of dozen points is plenty for fitting
r = np.hypot(P[:, 0] - PIVOT[0], PIVOT[1] - P[:, 1])
art = {'w': W, 'h': H, 'q': Q, 'pivot': list(PIVOT), 'reach': int(round(float(r.max()))),
       'hull': [int(round(float(v))) for v in hull.reshape(-1)], 'light': light, 'dark': dark}
(HERE / 'art.json').write_text(json.dumps(art, separators=(',', ':')))
print('art.json', round((HERE / 'art.json').stat().st_size / 1024, 1), 'KB | hull points', len(hull), '| reach', art['reach'], '| bbox', P.min(0).round(1).tolist(), P.max(0).round(1).tolist())
