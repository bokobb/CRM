/* ==========================================================================
   Три колоса на фоне страницы · «Юг Сладости»   (пара к kolos.css, без зависимостей)

   Рисунок — три колоса из печатного каталога, обведённые по контуру прямо с его
   картинки: линии те же самые, но остаются чёткими на любом экране. Колосья идут
   от левого нижнего угла экрана к правому верхнему и стоят на месте, пока
   страница прокручивается поверх. От прокрутки они качаются, а время от времени
   их треплет порыв ветра.

   Подключение:
     <link rel="stylesheet" href="kolos.css">
     <script src="kolos.js" defer></script>

   Разметка — первым элементом внутри каждого блока, за содержимым которого должны
   быть видны колосья (шапка с первым экраном, блок с каталогом):
     <div class="kolos" aria-hidden="true"></div>
   Блоков может быть несколько: рисунок и ветер у них общие, поэтому линия без
   разрыва переходит из блока в блок, а цвет у каждого блока свой.

   Настройка — CSS-переменные элемента .kolos:
     --kolos-top: 84px       сколько сверху закрыто шапкой сайта   (одинаково для всех блоков)
     --kolos-bottom: 0px     сколько снизу закрыто закреплённой панелью, если она есть
     --kolos-color: #E6C961  цвет линий в этом блоке

   Тексту поверх рисунка помогает класс kolos-text (ореол вокруг букв) — он описан в kolos.css.

   Из кода:
     YugKolos.gust()                          порыв ветра прямо сейчас
     document.addEventListener('kolos:gust')  событие в начале каждого порыва (detail: power, dir, dur) —
                                              чтобы на ветер откликалось и что-то ещё на странице
   Если у человека в системе отключена анимация, колосья нарисованы неподвижно.
   ========================================================================== */
(function () {
  'use strict';
  if (window.YugKolos || !window.Path2D) return;

  /* Рисунок. Единицы — пиксели картинки из каталога (1131 × 882), записаны в десятых долях, отражены зеркально:
     стебли слева внизу, колосья смотрят вправо вверх (как на страницах каталога с колосьями в правом углу).
     light — все штрихи, dark — середины жирных штрихов: в каталоге тонкие линии светлее жирных.
     pivot — точка, где сходятся стебли; reach — расстояние от неё до самой дальней верхушки. */
  var ART = /*ART*/null;

  var PALE = 0.45;       // насколько тонкие линии светлее жирных
  var STIFF = 13;        // жёсткость стебля: чем больше, тем быстрее колос возвращается
  var DAMP = 1.2;        // затухание: чем больше, тем меньше качаний после порыва
  var CURVE = 1.6;       // как наклон нарастает к верхушке: у места, где сходятся стебли, рисунок почти неподвижен
  var TURN = [-18, 34];  // на сколько градусов рисунок можно повернуть, вписывая в экран (минус — положе, плюс — круче)
  var WIND = 20;         // ветер дует слева и немного сверху: на столько градусов вниз от горизонтали
  /* Три колоса — нижний, средний, верхний. at — под каким углом к горизонтали колос смотрит на рисунке,
     stiff — насколько жёсткий стебель, lag — на сколько секунд позже до него доходит порыв,
     ph — сдвиг такта, в котором он качается на ветерке. */
  var EARS = [
    { at: 18, stiff: 1.2, lag: 0.16, ph: 0 },
    { at: 35, stiff: 1, lag: 0.08, ph: 2.1 },
    { at: 51, stiff: 0.86, lag: 0, ph: 4.4 }
  ];
  /* Между колосьями на рисунке пусто; в этих промежутках (градусы от горизонтали) наклон одного колоса
     плавно сменяется наклоном соседнего, поэтому рисунок нигде не рвётся. */
  var SPLIT = [[24, 32], [41, 47]];

  var LIGHT = null, DARK = null;
  var views = [];        // слои .kolos на странице: у каждого свой холст и свой цвет
  var still = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : { matches: false };
  /* Погода и посадка рисунка на экране — одни на всю страницу, поэтому во всех блоках колосья стоят и качаются одинаково. */
  var wind = {
    on: false, t: 0, last: 0, drawn: 0, late: 0,
    b: [0, 0, 0], v: [0, 0, 0],                 // наклон каждого колоса (радианы у самой дальней верхушки) и скорость наклона
    gust: null, nextGust: -1, lastY: 0
  };
  var geo = {
    W: 0, H: 0, dpr: 1,
    s: 1, a: 0, ox: 0, oy: 0,                   // масштаб, поворот и место на экране, где сходятся стебли
    gain: [1, 1, 1],                            // насколько каждый колос поддаётся ветру при нынешнем повороте рисунка
    sway: 1                                     // во сколько раз ослаблены порывы на узком экране
  };

  function clamp(x, a, b) { return x < a ? a : x > b ? b : x; }
  function rand(a, b) { return a + Math.random() * (b - a); }
  function ease(t) { return t * t * (3 - 2 * t); }

  /* ---- разбор рисунка: один раз, когда на странице нашёлся .kolos ---- */
  function layer(str) {
    var tok = str.match(/[Mlc]|-?\d+/g), n = tok.length, kinds = [], pts = [], i = 0, x = 0, y = 0, k, c;
    while (i < n) {
      c = tok[i++];
      if (c === 'M') { x = +tok[i++]; y = +tok[i++]; kinds.push(0); pts.push(x, y); }                         // начало контура
      else if (c === 'l') { x += +tok[i++]; y += +tok[i++]; kinds.push(1); pts.push(x, y); }                  // отрезок
      else {                                                                                                  // кривая: две опорные точки и конец
        for (k = 0; k < 2; k += 1) { pts.push(x + +tok[i], y + +tok[i + 1]); i += 2; }
        x += +tok[i++]; y += +tok[i++]; kinds.push(2); pts.push(x, y);
      }
    }
    /* для каждой точки заранее считаем: где она относительно места схождения стеблей и насколько её двигает каждый из трёх колосьев */
    var m = pts.length / 2, rel = new Float32Array(m * 2), gw = new Float32Array(m * 3), dx, dy, phi, g, low, top;
    for (i = 0; i < m; i += 1) {
      dx = pts[i * 2] / ART.q - ART.pivot[0]; dy = pts[i * 2 + 1] / ART.q - ART.pivot[1];
      rel[i * 2] = dx; rel[i * 2 + 1] = dy;
      phi = Math.atan2(-dy, dx) * 180 / Math.PI;                                    // угол от горизонтали вверх
      g = Math.pow(Math.min(1, Math.sqrt(dx * dx + dy * dy) / ART.reach), CURVE);   // чем дальше от стеблей, тем сильнее наклон
      low = 1 - ease(clamp((phi - SPLIT[0][0]) / (SPLIT[0][1] - SPLIT[0][0]), 0, 1));
      top = ease(clamp((phi - SPLIT[1][0]) / (SPLIT[1][1] - SPLIT[1][0]), 0, 1));
      gw[i * 3] = g * low; gw[i * 3 + 1] = g * (1 - low - top); gw[i * 3 + 2] = g * top;
    }
    return { kinds: new Uint8Array(kinds), rel: rel, gw: gw };
  }

  /* ---- слой в одном блоке страницы ---- */
  function View(el) {
    var self = this;
    this.el = el;
    el.parentNode.classList.add('kolos-host');
    this.cv = document.createElement('canvas');
    el.appendChild(this.cv);
    this.ctx = this.cv.getContext('2d');
    this.color = '';
    this.seen = !window.IntersectionObserver;
    if (window.IntersectionObserver) {
      new IntersectionObserver(function (e) { self.seen = e[e.length - 1].isIntersecting; sync(); }).observe(el);
    }
  }

  /* ---- размеры: вписываем рисунок в экран ---- */
  function measure() {
    if (!views.length) return;
    var cv = views[0].cv, W = cv.clientWidth, H = cv.clientHeight;
    if (!W || !H) return;
    var dpr = Math.min(window.devicePixelRatio || 1, 2, Math.sqrt(3.2e6 / (W * H)));
    function v(el, name, def) { return (getComputedStyle(el).getPropertyValue(name) || '').trim() || def; }
    views.forEach(function (view) {
      view.cv.width = Math.round(W * dpr); view.cv.height = Math.round(H * dpr);
      view.color = v(view.el, '--kolos-color', '#E6C961');
    });
    geo.W = W; geo.H = H; geo.dpr = dpr;
    var top = parseFloat(v(views[0].el, '--kolos-top', '0')) || 0, bottom = parseFloat(v(views[0].el, '--kolos-bottom', '0')) || 0;
    /* поле для рисунка — от левого нижнего угла экрана до правого верхнего: концы стеблей чуть уходят за левый край,
       сверху и снизу оставлен запас, чтобы колосья, качаясь, не уходили под шапку и за нижний край */
    var fh = H - top - bottom, x0 = -0.012 * W, x1 = 0.985 * W, y0 = top + 0.05 * fh, y1 = H - bottom - 0.03 * fh;
    /* подбираем поворот, при котором рисунок занимает поле целиком: на широком экране колосья ложатся положе, на телефоне встают круче */
    var hull = ART.hull, best = null, deg, a, ca, sa, i, dx, dy, x, y, minx, maxx, miny, maxy, s;
    for (deg = TURN[0]; deg <= TURN[1]; deg += 1) {
      a = deg * Math.PI / 180; ca = Math.cos(a); sa = Math.sin(a);
      minx = miny = 1e9; maxx = maxy = -1e9;
      for (i = 0; i < hull.length; i += 2) {
        dx = hull[i] - ART.pivot[0]; dy = hull[i + 1] - ART.pivot[1];
        x = dx * ca + dy * sa; y = dy * ca - dx * sa;
        if (x < minx) minx = x;
        if (x > maxx) maxx = x;
        if (y < miny) miny = y;
        if (y > maxy) maxy = y;
      }
      s = Math.min((x1 - x0) / (maxx - minx), (y1 - y0) / (maxy - miny));
      if (!best || s > best.s) best = { s: s, a: a, minx: minx, maxy: maxy };
    }
    geo.s = best.s; geo.a = best.a;
    geo.ox = x0 - best.minx * best.s; geo.oy = y1 - best.maxy * best.s;
    /* ветер сильнее клонит тот колос, что стоит к нему боком, и почти не трогает лежащий вдоль ветра */
    for (i = 0; i < 3; i += 1) geo.gain[i] = Math.max(0.3, Math.sin(EARS[i].at * Math.PI / 180 + best.a + WIND * Math.PI / 180));
    /* на узком экране тот же наклон унёс бы верхушки далеко за край, поэтому порывы и толчки от прокрутки там слабее */
    geo.sway = clamp(0.9 * W / (ART.reach * best.s), 0.4, 1);
    draw(true);
  }

  /* ---- включение: только когда хоть один блок с колосьями на экране и анимация разрешена ---- */
  function sync() {
    var run = !still.matches && views.some(function (view) { return view.seen; });
    if (run === wind.on) { if (!run) draw(true); return; }
    wind.on = run;
    if (!run) { wind.b = [0, 0, 0]; wind.v = [0, 0, 0]; wind.gust = null; draw(true); return; }
    wind.last = 0;
    wind.lastY = window.pageYOffset;
    if (wind.nextGust < 0) wind.nextGust = wind.t + rand(2.2, 3.6);   // первый порыв — вскоре после того, как колосья показались
    requestAnimationFrame(frame);
  }
  function blow(power, dir) {
    dir = dir || (Math.random() < 0.8 ? 1 : -1);                  // чаще слева; встречный порыв справа бывает реже и он слабее
    var g = wind.gust = { t0: wind.t, dur: rand(1.4, 2.2), power: (power || rand(0.2, 0.3)) * (dir < 0 ? 0.55 : 1), dir: dir };
    wind.nextGust = wind.t + g.dur + rand(8, 15);
    if (wind.on && window.CustomEvent) document.dispatchEvent(new CustomEvent('kolos:gust', { detail: { power: g.power, dir: g.dir, dur: g.dur } }));
  }

  /* ---- один кадр: ветер, прокрутка, пружина ---- */
  function frame(now) {
    if (!wind.on) return;
    requestAnimationFrame(frame);
    var gap = wind.last ? now - wind.last : 16, dt = Math.min(0.05, gap / 1000);
    wind.last = now;
    wind.t += dt;
    wind.late += ((gap > 24 ? 1 : 0) - wind.late) * 0.05;     // доля кадров, которые пришли с опозданием
    var t = wind.t, y = window.pageYOffset, dy = y - wind.lastY, g = wind.gust, busy = false, i, E, e, force;
    wind.lastY = y;
    if (g && t - g.t0 > g.dur + 0.3) g = wind.gust = null;
    if (!g && t > wind.nextGust) { blow(); g = wind.gust; }
    var kick = clamp(-dy * 0.0011, -0.3, 0.3) * geo.sway;     // прокрутка толкает колосья: листаем вниз — выпрямляются, вверх — клонятся
    for (i = 0; i < 3; i += 1) {
      E = EARS[i];
      /* лёгкий постоянный ветерок, у каждого колоса свой такт */
      force = STIFF * 0.013 * geo.gain[i] * (Math.sin(t * 0.7 + E.ph) + 0.6 * Math.sin(t * 1.9 + 1.3 + E.ph) + 0.35 * Math.sin(t * 3.1 + 4 + E.ph));
      /* порыв: быстро налетает, дольше стихает, внутри — дрожь */
      if (g) {
        e = (t - g.t0 - E.lag) / g.dur;
        if (e > 0 && e < 1) {
          force += g.dir * g.power * geo.sway * STIFF * geo.gain[i] * (e < 0.18 ? e / 0.18 : Math.pow(1 - (e - 0.18) / 0.82, 1.6)) *
            (1 + 0.3 * Math.sin(t * 19 + i) + 0.18 * Math.sin(t * 31 + 2 + i));
        }
      }
      wind.v[i] += kick;
      wind.v[i] += (-STIFF * E.stiff * wind.b[i] - DAMP * wind.v[i] + force) * dt;
      wind.b[i] += wind.v[i] * dt;
      if (wind.b[i] < -0.2 || wind.b[i] > 0.42) { wind.b[i] = clamp(wind.b[i], -0.2, 0.42); wind.v[i] = 0; }   // дальше колос не гнётся
      if (Math.abs(wind.v[i]) > 0.06) busy = true;
    }
    /* в тихую погоду хватает 30 кадров в секунду; в порыв и при прокрутке — до 60,
       а если устройство за этим не успевает, то тоже 30 */
    if (now - wind.drawn < (!g && !busy && Math.abs(dy) < 1 || wind.late > 0.5 ? 30 : 14)) return;
    wind.drawn = now;
    draw(false);
  }

  /* ---- рисунок: контуры считаются один раз на кадр, потом заливаются в каждом блоке его цветом ---- */
  function outline(L) {                               // каждая точка повёрнута вокруг места схождения стеблей на свой угол
    var p = new Path2D(), kinds = L.kinds, rel = L.rel, gw = L.gw, b0 = wind.b[0], b1 = wind.b[1], b2 = wind.b[2];
    var n = kinds.length, j = 0, i, k, th, cs, sn, x, y, x1, y1, x2, y2;
    for (i = 0; i < n; i += 1) {
      k = kinds[i];
      if (k === 2) {
        th = gw[j * 3] * b0 + gw[j * 3 + 1] * b1 + gw[j * 3 + 2] * b2; cs = Math.cos(th); sn = Math.sin(th);
        x1 = rel[j * 2] * cs - rel[j * 2 + 1] * sn; y1 = rel[j * 2] * sn + rel[j * 2 + 1] * cs; j += 1;
        th = gw[j * 3] * b0 + gw[j * 3 + 1] * b1 + gw[j * 3 + 2] * b2; cs = Math.cos(th); sn = Math.sin(th);
        x2 = rel[j * 2] * cs - rel[j * 2 + 1] * sn; y2 = rel[j * 2] * sn + rel[j * 2 + 1] * cs; j += 1;
      }
      th = gw[j * 3] * b0 + gw[j * 3 + 1] * b1 + gw[j * 3 + 2] * b2; cs = Math.cos(th); sn = Math.sin(th);
      x = rel[j * 2] * cs - rel[j * 2 + 1] * sn; y = rel[j * 2] * sn + rel[j * 2 + 1] * cs; j += 1;
      if (k === 0) { if (i) p.closePath(); p.moveTo(x, y); }
      else if (k === 1) p.lineTo(x, y);
      else p.bezierCurveTo(x1, y1, x2, y2, x, y);
    }
    p.closePath();
    return p;
  }
  function draw(everywhere) {                         // everywhere — во всех блоках, а не только в тех, что сейчас на экране
    if (!geo.W) return;
    var d = geo.dpr, s = geo.s * d, ca = Math.cos(geo.a) * s, sa = Math.sin(geo.a) * s, light = null, dark = null;
    views.forEach(function (view) {
      if (!everywhere && !view.seen) return;
      if (!light) { light = outline(LIGHT); dark = outline(DARK); }
      var c = view.ctx;
      c.setTransform(1, 0, 0, 1, 0, 0);
      c.clearRect(0, 0, view.cv.width, view.cv.height);
      c.setTransform(ca, -sa, sa, ca, geo.ox * d, geo.oy * d);
      c.fillStyle = view.color;
      c.globalAlpha = PALE; c.fill(light, 'evenodd');
      c.globalAlpha = 1; c.fill(dark, 'evenodd');
    });
  }

  /* ---- запуск ---- */
  function init(root) {
    var nodes = (root && root.querySelectorAll ? root : document).querySelectorAll('.kolos:not([data-kolos])');
    if (!nodes.length) return;
    if (!LIGHT) { LIGHT = layer(ART.light); DARK = layer(ART.dark); ART.light = ART.dark = ''; }
    var first = !views.length;
    Array.prototype.forEach.call(nodes, function (el) { el.setAttribute('data-kolos', ''); views.push(new View(el)); });
    if (first && window.ResizeObserver) new ResizeObserver(measure).observe(views[0].cv);
    measure();
    sync();
  }
  window.addEventListener('resize', measure);
  if (still.addEventListener) still.addEventListener('change', sync);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(document); }); else init(document);

  window.YugKolos = { init: init, gust: blow, views: views, wind: wind, geo: geo, redraw: function () { draw(true); } };
})();
