# kolos.src.js + art.json  →  ../kolos.js (the one file the site loads)
import json, pathlib
HERE = pathlib.Path(__file__).parent
src = (HERE / 'kolos.src.js').read_text(encoding='utf-8')
art = (HERE / 'art.json').read_text(encoding='utf-8').strip()
json.loads(art)                                     # must be valid JSON
assert src.count('/*ART*/null') == 1
out = src.replace('/*ART*/null', art)
(HERE.parent / 'kolos.js').write_text(out, encoding='utf-8')
print('kolos.js', round(len(out.encode()) / 1024, 1), 'KB')
